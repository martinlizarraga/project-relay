//
//  SalesView.swift
//  SOPHub
//
//  Created by Martin Lizarraga on 4/21/25.
//

import SwiftUI

struct SalesView: View {
    var body: some View{
        Text("Sales View")
            .font(.largeTitle)
            .padding()
    }
}

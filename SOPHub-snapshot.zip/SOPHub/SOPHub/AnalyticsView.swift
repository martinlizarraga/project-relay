//
//  AnalyticsView.swift
//  SOPHub
//
//  Created by Martin Lizarraga on 4/21/25.
//

import SwiftUI

struct AnalyticsView: View {
    var body: some View{
        Text("Analytics View")
            .font(.largeTitle)
            .padding()
    }
}

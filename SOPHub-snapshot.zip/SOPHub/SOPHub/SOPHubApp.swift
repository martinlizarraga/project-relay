//
//  SOPHubApp.swift
//  SOPHub
//
//  Created by Martin Lizarraga on 4/21/25.
//

import SwiftUI

@main
struct SOPHubApp: App {
    var body: some Scene {
        WindowGroup {
            HomeView()
        }
    }
}
